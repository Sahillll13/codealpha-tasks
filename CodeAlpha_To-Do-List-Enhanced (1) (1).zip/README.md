
# ProTask — Enhanced To‑Do Website

Upgraded from the original `CodeAlpha_To-Do-List-main` project.

## What's new

- ✅ Modern multi‑page website (Landing + App)
- ⚡ Fast, responsive UI with keyboard shortcuts
- 🗂️ Multiple lists (Projects)
- 🏷️ Tags, priorities, due dates, notes
- 🔍 Search, filter, and sort
- 🧲 Drag‑and‑drop reordering
- 💾 Local persistence (LocalStorage)
- ⬇️ Export / ⬆️ Import JSON
- 🌙 Theme toggle (saved)
- 📦 PWA: Installable + offline via service worker

## Files

- `index.html` — Landing page
- `app.html` — App page
- `assets/css/styles.css` — Styles
- `assets/js/app.js` — App logic
- `sw.js` — Service worker
- `manifest.webmanifest` — PWA manifest
- `original_backup/` — Your original files kept intact

## Run locally

Just open `index.html` in a browser.  
For service worker to work fully, serve via a local server (e.g., VS Code Live Server or `python -m http.server`).

