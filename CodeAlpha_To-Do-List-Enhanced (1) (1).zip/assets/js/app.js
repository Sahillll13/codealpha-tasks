
// LocalStorage key
const KEY = 'protask:data';
const THEME_KEY = 'protask:theme';

function uid(){ return Math.random().toString(36).slice(2) + Date.now().toString(36); }

function load(){
  try{
    const raw = localStorage.getItem(KEY);
    if(!raw) return { lists: [ { id: uid(), name: 'My Tasks', tasks: [] } ], activeListId: null };
    return JSON.parse(raw);
  }catch(e){
    console.error('load fail', e);
    return { lists: [ { id: uid(), name: 'My Tasks', tasks: [] } ], activeListId: null };
  }
}
function save(state){ localStorage.setItem(KEY, JSON.stringify(state)); }

function qs(id){ return document.getElementById(id); }

const state = load();
if(!state.activeListId){ state.activeListId = state.lists[0].id; }

const els = {
  listContainer: qs('listContainer'),
  newListName: qs('newListName'),
  addListBtn: qs('addListBtn'),
  search: qs('search'),
  filterStatus: qs('filterStatus'),
  filterPriority: qs('filterPriority'),
  filterTag: qs('filterTag'),
  sortBy: qs('sortBy'),
  clearCompleted: qs('clearCompleted'),
  taskForm: qs('taskForm'),
  title: qs('title'),
  due: qs('due'),
  priority: qs('priority'),
  tags: qs('tags'),
  notes: qs('notes'),
  taskList: qs('taskList'),
  exportBtn: qs('exportBtn'),
  importFile: qs('importFile'),
  themeToggle: document.getElementById('themeToggle')
};

// Theme
(function initTheme(){
  const t = localStorage.getItem(THEME_KEY) || 'dark';
  document.documentElement.dataset.theme = t;
  els.themeToggle?.addEventListener('click', ()=>{
    const cur = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = cur;
    localStorage.setItem(THEME_KEY, cur);
  });
})();

function activeList(){ return state.lists.find(l=>l.id===state.activeListId); }

function renderLists(){
  els.listContainer.innerHTML = '';
  state.lists.forEach(l=>{
    const btn = document.createElement('button');
    btn.textContent = l.name;
    btn.className = 'list-item' + (l.id===state.activeListId ? ' active': '');
    btn.setAttribute('role','option');
    btn.addEventListener('click', ()=>{ state.activeListId=l.id; save(state); render(); });
    els.listContainer.appendChild(btn);
  });
}

function renderTasks(){
  const list = activeList();
  if(!list){ els.taskList.innerHTML = '<p>No list selected.</p>'; return; }

  // Filter
  const q = els.search.value.trim().toLowerCase();
  const st = els.filterStatus.value;
  const pri = els.filterPriority.value;
  const tag = els.filterTag.value.trim().toLowerCase();

  let items = [...list.tasks];

  // Sorting
  const sortBy = els.sortBy.value;
  if(sortBy === 'dueAsc'){ items.sort((a,b)=> (a.due||'').localeCompare(b.due||'')); }
  else if(sortBy === 'dueDesc'){ items.sort((a,b)=> (b.due||'').localeCompare(a.due||'')); }
  else if(sortBy === 'priority'){ items.sort((a,b)=> (a.priority||99) - (b.priority||99)); }
  else if(sortBy === 'created'){ items.sort((a,b)=> (a.created||0) - (b.created||0)); }
  // manual keeps existing order

  // Filter pipeline
  items = items.filter(t=>{
    if(q && !((t.title||'').toLowerCase().includes(q) || (t.notes||'').toLowerCase().includes(q) || (t.tags||'').toLowerCase().includes(q))) return false;
    if(st==='active' && t.done) return false;
    if(st==='done' && !t.done) return false;
    if(pri!=='all' && String(t.priority)!==pri) return false;
    if(tag && !(t.tags||'').toLowerCase().split(/\s+/).includes(tag)) return false;
    return true;
  });

  els.taskList.innerHTML = '';
  items.forEach(task=>{
    const el = document.createElement('div');
    el.className = 'task';
    el.setAttribute('draggable','true');
    el.dataset.id = task.id;

    // Drag events
    el.addEventListener('dragstart', e=>{ el.classList.add('dragging'); e.dataTransfer.setData('text/plain', task.id); });
    el.addEventListener('dragend', ()=> el.classList.remove('dragging'));
    els.taskList.addEventListener('dragover', e=>{
      e.preventDefault();
      const dragging = document.querySelector('.task.dragging');
      const after = getDragAfterElement(e.clientY);
      if(after == null){ els.taskList.appendChild(dragging); }
      else{ els.taskList.insertBefore(dragging, after); }
    });
    els.taskList.addEventListener('drop', e=>{
      e.preventDefault();
      const ids = Array.from(els.taskList.querySelectorAll('.task')).map(x=>x.dataset.id);
      // reorder in list.tasks based on ids order
      list.tasks.sort((a,b)=> ids.indexOf(a.id) - ids.indexOf(b.id));
      save(state);
    });

    function getDragAfterElement(y){
      const elements = [...els.taskList.querySelectorAll('.task:not(.dragging)')];
      return elements.reduce((closest, child)=>{
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height/2;
        if(offset < 0 && offset > closest.offset){ return { offset, element: child}; }
        else{ return closest; }
      }, { offset: Number.NEGATIVE_INFINITY }).element;
    }

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = !!task.done;
    checkbox.addEventListener('change', ()=>{ task.done = checkbox.checked; save(state); renderTasks(); });

    const main = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = task.title;
    // Inline edit
    title.addEventListener('dblclick', ()=>{
      const input = document.createElement('input');
      input.value = task.title;
      input.addEventListener('keydown', e=>{
        if(e.key==='Enter'){ task.title = input.value.trim()||task.title; save(state); renderTasks(); }
      });
      input.addEventListener('blur', ()=>{ task.title = input.value.trim()||task.title; save(state); renderTasks(); });
      title.replaceWith(input);
      input.focus();
    });

    const meta = document.createElement('div');
    meta.className = 'meta';
    const chips = [];
    if(task.due){ chips.push(`<span class="chip ${overdue(task.due) ? 'warn':''}">Due ${task.due}</span>`); }
    if(task.priority){ chips.push(`<span class="chip ${task.priority==1?'bad': task.priority==3?'ok':''}">P${task.priority}</span>`); }
    if(task.tags){ task.tags.split(/\s+/).filter(Boolean).forEach(t=> chips.push(`<span class="chip">#${t.replace(/^#/,'')}</span>`)); }
    meta.innerHTML = chips.join(' ') || '&nbsp;';

    const notes = document.createElement('div');
    notes.className = 'meta';
    if(task.notes){ notes.textContent = task.notes; }

    main.appendChild(title);
    main.appendChild(meta);
    if(task.notes){ main.appendChild(notes); }

    const actions = document.createElement('div');
    actions.className = 'flex';
    const editBtn = document.createElement('button'); editBtn.className='btn'; editBtn.textContent='Edit';
    editBtn.addEventListener('click', ()=> openEditor(task));
    const delBtn = document.createElement('button'); delBtn.className='btn'; delBtn.textContent='Delete';
    delBtn.addEventListener('click', ()=>{
      if(confirm('Delete this task?')){
        list.tasks = list.tasks.filter(t=>t.id!==task.id);
        save(state); renderTasks();
      }
    });
    actions.appendChild(editBtn); actions.appendChild(delBtn);

    el.appendChild(checkbox);
    el.appendChild(main);
    el.appendChild(actions);

    els.taskList.appendChild(el);
  });
}

function overdue(dateStr){
  try{
    const d = new Date(dateStr+"T23:59:59");
    return d < new Date() && (new Date().toDateString() !== d.toDateString());
  }catch(e){ return false; }
}

function render(){ renderLists(); renderTasks(); }
render();

// Events
els.addListBtn.addEventListener('click', ()=>{
  const name = els.newListName.value.trim();
  if(!name) return;
  state.lists.push({ id: uid(), name, tasks: [] });
  state.activeListId = state.lists[state.lists.length-1].id;
  els.newListName.value = '';
  save(state); render();
});

els.taskForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const list = activeList();
  if(!list) return;
  const t = {
    id: uid(),
    title: els.title.value.trim(),
    due: els.due.value || null,
    priority: Number(els.priority.value),
    tags: els.tags.value.trim().split(/\s+/).map(t=>t.replace(/^#/,'')).filter(Boolean).join(' '),
    notes: els.notes.value.trim(),
    created: Date.now(),
    done: false
  };
  if(!t.title){ return; }
  list.tasks.push(t);
  e.target.reset();
  save(state); renderTasks();
});

['search','filterStatus','filterPriority','filterTag','sortBy'].forEach(id=>{
  els[id].addEventListener('input', renderTasks);
});
els.clearCompleted.addEventListener('click', ()=>{
  const list = activeList();
  if(!list) return;
  if(confirm('Clear all completed tasks?')){
    list.tasks = list.tasks.filter(t=>!t.done);
    save(state); renderTasks();
  }
});

// Keyboard
document.addEventListener('keydown', (e)=>{
  if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){
    e.preventDefault(); els.search.focus();
  }
});

// Export / Import
els.exportBtn.addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'protask-data.json'; a.click();
  URL.revokeObjectURL(url);
});
els.importFile.addEventListener('change', (e)=>{
  const file = e.target.files?.[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=>{
    try{
      const data = JSON.parse(reader.result);
      if(!data.lists) throw new Error('Invalid data');
      localStorage.setItem(KEY, JSON.stringify(data));
      Object.assign(state, data);
      if(!state.activeListId && state.lists.length){ state.activeListId = state.lists[0].id; }
      render();
      alert('Import successful!');
    }catch(err){
      alert('Import failed: ' + err.message);
    }
  };
  reader.readAsText(file);
});

// Editor modal (simple prompt based to keep code compact)
function openEditor(task){
  const title = prompt('Title:', task.title);
  if(title===null) return;
  const due = prompt('Due (YYYY-MM-DD):', task.due||'') || null;
  const priority = Number(prompt('Priority (1 High, 2 Med, 3 Low):', String(task.priority)))||2;
  const tags = prompt('Tags space-separated (without #):', task.tags||'') || '';
  const notes = prompt('Notes:', task.notes||'') || '';
  Object.assign(task, { title: title.trim()||task.title, due, priority, tags: tags.trim(), notes: notes.trim() });
  save(state); renderTasks();
}
